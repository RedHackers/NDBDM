<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\RhActivityAttend */

$this->title = 'Create Rh Activity Attend';
$this->params['breadcrumbs'][] = ['label' => 'Rh Activity Attends', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="rh-activity-attend-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
