<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\RhActivityAttend */

$this->title = 'Update Rh Activity Attend: ' . ' ' . $model->activity_id;
$this->params['breadcrumbs'][] = ['label' => 'Rh Activity Attends', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->activity_id, 'url' => ['view', 'activity_id' => $model->activity_id, 'member_name' => $model->member_name]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="rh-activity-attend-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
