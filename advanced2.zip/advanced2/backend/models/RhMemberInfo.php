<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%rh_member_info}}".
 *
 * @property string $member_name
 * @property string $member_major
 * @property string $live_pic_id
 * @property string $member_degree
 * @property string $member_duty
 * @property string $member_interest
 * @property string $member_email
 * @property string $member_live
 *
 * @property RhActivityAttend[] $rhActivityAttends
 * @property RhActivityInfo[] $activities
 * @property RhMemberLive $livePic
 */
class RhMemberInfo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%rh_member_info}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['member_name', 'member_major', 'live_pic_id', 'member_degree', 'member_duty', 'member_interest', 'member_email', 'member_live'], 'required'],
            [['live_pic_id'], 'integer'],
            [['member_live'], 'string'],
            [['member_name'], 'string', 'max' => 15],
            [['member_major', 'member_degree', 'member_duty', 'member_interest'], 'string', 'max' => 20],
            [['member_email'], 'string', 'max' => 40]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'member_name' => 'Member Name',
            'member_major' => 'Member Major',
            'live_pic_id' => 'Live Pic ID',
            'member_degree' => 'Member Degree',
            'member_duty' => 'Member Duty',
            'member_interest' => 'Member Interest',
            'member_email' => 'Member Email',
            'member_live' => 'Member Live',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRhActivityAttends()
    {
        return $this->hasMany(RhActivityAttend::className(), ['member_name' => 'member_name']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getActivities()
    {
        return $this->hasMany(RhActivityInfo::className(), ['activity_id' => 'activity_id'])->viaTable('{{%rh_activity_attend}}', ['member_name' => 'member_name']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLivePic()
    {
        return $this->hasOne(RhMemberLive::className(), ['live_pic_id' => 'live_pic_id']);
    }
}
