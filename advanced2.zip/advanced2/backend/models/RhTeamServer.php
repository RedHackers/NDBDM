<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%rh_team_server}}".
 *
 * @property string $server_name
 * @property integer $server_member_num
 */
class RhTeamServer extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%rh_team_server}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['server_name'], 'required'],
            [['server_member_num'], 'integer'],
            [['server_name'], 'string', 'max' => 20]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'server_name' => 'Server Name',
            'server_member_num' => 'Server Member Num',
        ];
    }
}
