<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%rh_note_record}}".
 *
 * @property string $user_name
 * @property string $note_email
 * @property string $note_content
 * @property string $note_id
 *
 * @property RhNoteShow $rhNoteShow
 */
class RhNoteRecord extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%rh_note_record}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_name', 'note_email', 'note_content'], 'required'],
            [['note_content'], 'string'],
            [['user_name'], 'string', 'max' => 15],
            [['note_email'], 'string', 'max' => 40]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'user_name' => 'User Name',
            'note_email' => 'Note Email',
            'note_content' => 'Note Content',
            'note_id' => 'Note ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRhNoteShow()
    {
        return $this->hasOne(RhNoteShow::className(), ['note_id' => 'note_id']);
    }

// 修改
    public function getRhNoteRecord()
    {
        return $this->hasOne(RhNoteRecord::className(), ['uid' => 'uid']);
    }

}
