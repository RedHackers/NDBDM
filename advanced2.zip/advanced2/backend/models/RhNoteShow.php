<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%rh_note_show}}".
 *
 * @property string $note_id
 *
 * @property RhNoteRecord $note
 */
class RhNoteShow extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%rh_note_show}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['note_id'], 'required'],
            [['note_id'], 'integer']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'note_id' => 'Note ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNote()
    {
        return $this->hasOne(RhNoteRecord::className(), ['note_id' => 'note_id']);
    }
}
