<?php

namespace frontend\controllers;

use Yii;
use frontend\models\RhActivityAttend;
use frontend\models\RhActivityAttendSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * RhActivityAttendController implements the CRUD actions for RhActivityAttend model.
 */
class RhActivityAttendController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all RhActivityAttend models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RhActivityAttendSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single RhActivityAttend model.
     * @param string $activity_id
     * @param string $member_name
     * @return mixed
     */
    public function actionView($activity_id, $member_name)
    {
        return $this->render('view', [
            'model' => $this->findModel($activity_id, $member_name),
        ]);
    }

    /**
     * Creates a new RhActivityAttend model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new RhActivityAttend();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'activity_id' => $model->activity_id, 'member_name' => $model->member_name]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing RhActivityAttend model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $activity_id
     * @param string $member_name
     * @return mixed
     */
    public function actionUpdate($activity_id, $member_name)
    {
        $model = $this->findModel($activity_id, $member_name);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'activity_id' => $model->activity_id, 'member_name' => $model->member_name]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing RhActivityAttend model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $activity_id
     * @param string $member_name
     * @return mixed
     */
    public function actionDelete($activity_id, $member_name)
    {
        $this->findModel($activity_id, $member_name)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the RhActivityAttend model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $activity_id
     * @param string $member_name
     * @return RhActivityAttend the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($activity_id, $member_name)
    {
        if (($model = RhActivityAttend::findOne(['activity_id' => $activity_id, 'member_name' => $member_name])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
