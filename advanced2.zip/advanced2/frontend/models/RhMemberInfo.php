<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "{{%rh_member_info}}".
 *
 * @property string $member_name
 * @property string $menber_major
 * @property string $live_pic_id
 * @property string $menber_degree
 * @property string $menber_duty
 * @property string $menber_interest
 * @property string $member_email
 * @property string $member_live
 *
 * @property RhActivityAttend[] $rhActivityAttends
 * @property RhMemberLive $livePic
 */
class RhMemberInfo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%rh_member_info}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['member_name', 'menber_major', 'live_pic_id', 'menber_degree', 'menber_duty', 'menber_interest', 'member_email', 'member_live'], 'required'],
            [['live_pic_id'], 'integer'],
            [['member_live'], 'string'],
            [['member_name'], 'string', 'max' => 15],
            [['menber_major', 'menber_degree', 'menber_duty', 'menber_interest'], 'string', 'max' => 20],
            [['member_email'], 'string', 'max' => 40],
            [['live_pic_id'], 'exist', 'skipOnError' => true, 'targetClass' => RhMemberLive::className(), 'targetAttribute' => ['live_pic_id' => 'live_pic_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'member_name' => '成员名称',
            'menber_major' => '成员专业',
            'live_pic_id' => '成员图片id',
            'menber_degree' => '成员学历',
            'menber_duty' => '成员职务',
            'menber_interest' => '成员兴趣方向',
            'member_email' => '成员电子邮箱',
            'member_live' => '成员经历',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRhActivityAttends()
    {
        return $this->hasMany(RhActivityAttend::className(), ['member_name' => 'member_name']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLivePic()
    {
        return $this->hasOne(RhMemberLive::className(), ['live_pic_id' => 'live_pic_id']);
    }
}
