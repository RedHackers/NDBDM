<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "{{%rh_background_admin}}".
 *
 * @property string $adminID
 * @property string $admin_password
 */
class RhBackgroundAdmin extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%rh_background_admin}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['adminID', 'admin_password'], 'required'],
            [['adminID'], 'string', 'max' => 15],
            [['admin_password'], 'string', 'max' => 32],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'adminID' => '管理员编号',
            'admin_password' => '管理员密码',
        ];
    }
}
