<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model frontend\models\RhBackgroundAdmin */

$this->title = 'Update Rh Background Admin: ' . $model->adminID;
$this->params['breadcrumbs'][] = ['label' => 'Rh Background Admins', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->adminID, 'url' => ['view', 'id' => $model->adminID]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="rh-background-admin-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
