<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model frontend\models\RhBackgroundAdmin */

$this->title = 'Create Rh Background Admin';
$this->params['breadcrumbs'][] = ['label' => 'Rh Background Admins', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="rh-background-admin-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
