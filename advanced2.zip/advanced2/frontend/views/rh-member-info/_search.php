<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model frontend\models\RhMemberInfoSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="rh-member-info-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'member_name') ?>

    <?= $form->field($model, 'menber_major') ?>

    <?= $form->field($model, 'live_pic_id') ?>

    <?= $form->field($model, 'menber_degree') ?>

    <?= $form->field($model, 'menber_duty') ?>

    <?php // echo $form->field($model, 'menber_interest') ?>

    <?php // echo $form->field($model, 'member_email') ?>

    <?php // echo $form->field($model, 'member_live') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
